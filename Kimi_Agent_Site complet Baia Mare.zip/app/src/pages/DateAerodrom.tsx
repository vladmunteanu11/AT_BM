import { 
  Plane, 
  Navigation, 
  Radio, 
  MapPin,
  Phone,
  Clock,
  CheckCircle2,
  XCircle,
  Info
} from 'lucide-react';

const runwaySpecs = [
  { label: 'Lungime', value: '500 m' },
  { label: 'Lățime', value: '30 m' },
  { label: 'Direcții', value: '09 / 27' },
  { label: 'Suprafață', value: 'Iarbă/Beton' },
];

const taxiwaySpecs = [
  { label: 'Lungime', value: '610 m' },
  { label: 'Lățime', value: '20 m' },
  { label: 'Denumire', value: 'Alfa' },
];

const commSpecs = [
  { label: 'Frecvență', value: '135.210 MHz' },
  { label: 'Cod ICAO', value: 'LRMM' },
  { label: 'Elevație', value: '184.8 m' },
];

const facilities = [
  { name: 'Hangar', available: true },
  { name: 'Service tehnic', available: true, note: 'Wilga, Planor' },
  { name: 'Combustibil', available: false },
  { name: 'Cazare', available: true, note: '6.1 km' },
  { name: 'Restaurant', available: true, note: '2.5 km' },
];

export function DateAerodrom() {
  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center gap-3 text-white/40 mb-6">
            <div className="w-12 h-px bg-white/20" />
            <span className="text-xs tracking-widest uppercase">Informații pentru piloți</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-medium text-white leading-tight max-w-3xl">
            Date tehnice și specificații
          </h1>
        </div>
      </section>

      {/* Location Card */}
      <section className="py-16 bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">Locație</span>
              <h2 className="text-2xl font-medium text-slate-900 mb-4">
                Aerodrom Tăuții-Măgherăuș
              </h2>
              <div className="space-y-3 text-slate-600">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 mt-0.5 text-slate-400" strokeWidth={1.5} />
                  <span>Str. 66, Nr. 5, Tăuții-Măgherăuș, Maramureș</span>
                </div>
                <div className="flex items-start gap-3">
                  <Navigation className="w-5 h-5 mt-0.5 text-slate-400" strokeWidth={1.5} />
                  <span>7.5 km față de centrul Baia Mare</span>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 mt-0.5 text-slate-400" strokeWidth={1.5} />
                  <span>Regim HX (Răsărit - Apus)</span>
                </div>
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 mt-0.5 text-slate-400" strokeWidth={1.5} />
                  <span>0726 678 535</span>
                </div>
              </div>
            </div>
            <div className="bg-slate-50 p-8">
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <span className="text-xs tracking-widest uppercase text-slate-400 mb-2 block">Cod ICAO</span>
                  <span className="text-3xl font-medium text-slate-900">LRMM</span>
                </div>
                <div>
                  <span className="text-xs tracking-widest uppercase text-slate-400 mb-2 block">Elevație</span>
                  <span className="text-3xl font-medium text-slate-900">184.8 m</span>
                </div>
                <div>
                  <span className="text-xs tracking-widest uppercase text-slate-400 mb-2 block">Latitudine</span>
                  <span className="text-xl text-slate-900">47°40'N</span>
                </div>
                <div>
                  <span className="text-xs tracking-widest uppercase text-slate-400 mb-2 block">Longitudine</span>
                  <span className="text-xl text-slate-900">23°28'E</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Specifications Grid */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Runway */}
            <div className="bg-white p-8">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-slate-100 flex items-center justify-center">
                  <Plane className="w-5 h-5 text-slate-700" strokeWidth={1.5} />
                </div>
                <h3 className="font-medium text-slate-900">Pistă</h3>
              </div>
              <div className="space-y-4">
                {runwaySpecs.map((spec) => (
                  <div key={spec.label} className="flex justify-between items-center py-3 border-b border-slate-100 last:border-0">
                    <span className="text-slate-500 text-sm">{spec.label}</span>
                    <span className="font-medium text-slate-900">{spec.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Taxiway */}
            <div className="bg-white p-8">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-slate-100 flex items-center justify-center">
                  <Navigation className="w-5 h-5 text-slate-700" strokeWidth={1.5} />
                </div>
                <h3 className="font-medium text-slate-900">Cale de rulaj</h3>
              </div>
              <div className="space-y-4">
                {taxiwaySpecs.map((spec) => (
                  <div key={spec.label} className="flex justify-between items-center py-3 border-b border-slate-100 last:border-0">
                    <span className="text-slate-500 text-sm">{spec.label}</span>
                    <span className="font-medium text-slate-900">{spec.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Communication */}
            <div className="bg-white p-8">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 bg-slate-100 flex items-center justify-center">
                  <Radio className="w-5 h-5 text-slate-700" strokeWidth={1.5} />
                </div>
                <h3 className="font-medium text-slate-900">Comunicare</h3>
              </div>
              <div className="space-y-4">
                {commSpecs.map((spec) => (
                  <div key={spec.label} className="flex justify-between items-center py-3 border-b border-slate-100 last:border-0">
                    <span className="text-slate-500 text-sm">{spec.label}</span>
                    <span className="font-medium text-slate-900">{spec.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Facilities */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-16">
            <div className="lg:col-span-4">
              <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">Facilități</span>
              <h2 className="text-2xl font-medium text-slate-900">
                Servicii disponibile
              </h2>
            </div>
            <div className="lg:col-span-8">
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {facilities.map((facility) => (
                  <div 
                    key={facility.name} 
                    className={`p-6 border ${facility.available ? 'border-slate-200' : 'border-slate-100 bg-slate-50/50'}`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <span className={`font-medium ${facility.available ? 'text-slate-900' : 'text-slate-400'}`}>
                        {facility.name}
                      </span>
                      {facility.available ? (
                        <CheckCircle2 className="w-5 h-5 text-green-600" strokeWidth={1.5} />
                      ) : (
                        <XCircle className="w-5 h-5 text-slate-300" strokeWidth={1.5} />
                      )}
                    </div>
                    {facility.note && (
                      <span className="text-xs text-slate-500">{facility.note}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Notice */}
      <section className="py-16 bg-amber-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-amber-100 flex items-center justify-center flex-shrink-0">
              <Info className="w-5 h-5 text-amber-700" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="font-medium text-amber-900 mb-2">Notă importantă</h3>
              <p className="text-amber-800/80 text-sm leading-relaxed max-w-3xl">
                Conform procedurilor aerodromului, înregistrarea aeronavelor în Registrul de Mișcări 
                este obligatorie la sosire. Vă rugăm să vă asigurați că datele sunt completate corect. 
                Tarifele pentru aterizare și staționare/hangarare sunt conform Ordinului MTI 1503/2018.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
