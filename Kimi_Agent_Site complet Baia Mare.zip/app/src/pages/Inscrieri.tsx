import { 
  GraduationCap, 
  Calendar, 
  FileText, 
  CheckCircle2,
  Plane,
  Wind,
  ArrowRight,
  User,
  Phone,
  AlertCircle,
  ArrowUpRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

const courses = [
  {
    icon: Plane,
    title: 'Pilot Avion Ușor',
    subtitle: 'LAPL',
    description: 'Licență pentru pilotarea avioanelor ușoare cu maximum 3 pasageri.',
    duration: '6-12 luni',
    age: '17 ani',
    price: 'Gratuit pentru tineri*',
  },
  {
    icon: Wind,
    title: 'Pilot Planor',
    subtitle: 'SPL',
    description: 'Licență pentru pilotarea planoarelor și motoplanourilor.',
    duration: '6-12 luni',
    age: '16 ani',
    price: 'Gratuit pentru tineri*',
  },
  {
    icon: GraduationCap,
    title: 'Parașutism',
    subtitle: 'AFF',
    description: 'Curs complet de parașutism cu metoda Accelerated Free Fall.',
    duration: '3-6 luni',
    age: '16 ani',
    price: 'Gratuit pentru tineri*',
  },
];

const requirements = [
  'Vârsta minimă: 16 ani pentru planorism și parașutism, 17 ani pentru avion',
  'Certificat medical aeronautic valabil',
  'Cazier judiciar fără antecedente penale',
  'Cetățenie română sau rezidență legală în România',
];

const documents = [
  'Copie CI/Passaport',
  'Certificat medical aeronautic',
  'Cazier judiciar',
  'Adeverință de la locul de muncă sau școală',
  '4 fotografii tip buletin',
];

const steps = [
  {
    number: '01',
    title: 'Completează formularul',
    description: 'Accesează platforma online și completează formularul de înscriere cu datele tale.',
  },
  {
    number: '02',
    title: 'Pregătește documentele',
    description: 'Adună toate documentele necesare conform listei de mai sus.',
  },
  {
    number: '03',
    title: 'Examen medical',
    description: 'Efectuează examenul medical aeronautic la un medic autorizat AACR.',
  },
  {
    number: '04',
    title: 'Validare înscriere',
    description: 'Vino la aerodrom cu documentele pentru validarea înscrierii.',
  },
];

export function Inscrieri() {
  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center gap-3 text-white/40 mb-6">
            <div className="w-12 h-px bg-white/20" />
            <span className="text-xs tracking-widest uppercase">Înscrieri</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-medium text-white leading-tight max-w-3xl mb-6">
            Începe-ți cariera în aviație
          </h1>
          <p className="text-lg text-white/50 max-w-xl">
            Cursuri gratuite de planorism și parașutism pentru tinerii cu vârste între 16 și 23 de ani.
          </p>
        </div>
      </section>

      {/* Free Courses Banner */}
      <section className="py-12 bg-slate-900 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div>
              <span className="text-xs tracking-widest uppercase text-white/40 mb-2 block">Oportunitate</span>
              <h2 className="text-xl font-medium text-white">Cursuri gratuite pentru tineri</h2>
              <p className="text-white/50 text-sm mt-1">Vârsta 16-23 ani • Locuri limitate</p>
            </div>
            <a
              href="https://legitimare.ar.ro/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 px-6 py-3.5 bg-white text-slate-900 text-sm tracking-wide hover:bg-white/90 transition-colors"
            >
              <span>Înscrie-te online</span>
              <ArrowUpRight className="w-4 h-4" strokeWidth={1.5} />
            </a>
          </div>
        </div>
      </section>

      {/* Courses */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="mb-16">
            <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">Cursuri disponibile</span>
            <h2 className="text-3xl font-medium text-slate-900">
              Alege-ți specializarea
            </h2>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {courses.map((course) => (
              <div key={course.title} className="group bg-slate-50 p-8 hover:bg-slate-100 transition-colors">
                <div className="flex items-start justify-between mb-6">
                  <div className="w-12 h-12 bg-white flex items-center justify-center">
                    <course.icon className="w-6 h-6 text-slate-700" strokeWidth={1.5} />
                  </div>
                  <span className="text-xs tracking-widest uppercase text-slate-400">{course.subtitle}</span>
                </div>
                <h3 className="text-xl font-medium text-slate-900 mb-3">{course.title}</h3>
                <p className="text-slate-600 text-sm leading-relaxed mb-6">{course.description}</p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-slate-500">
                    <Calendar className="w-4 h-4" strokeWidth={1.5} />
                    <span>Durată: {course.duration}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-500">
                    <User className="w-4 h-4" strokeWidth={1.5} />
                    <span>Vârstă minimă: {course.age}</span>
                  </div>
                </div>
                <div className="mt-6 pt-6 border-t border-slate-200">
                  <span className="text-sm font-medium text-green-700">{course.price}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Requirements & Documents */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Requirements */}
            <div>
              <span className="text-xs tracking-widest uppercase text-slate-400 mb-6 block">Condiții</span>
              <h3 className="text-2xl font-medium text-slate-900 mb-8">Condiții de înscriere</h3>
              <ul className="space-y-4">
                {requirements.map((req, index) => (
                  <li key={index} className="flex items-start gap-4">
                    <div className="w-6 h-6 bg-slate-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-slate-700" strokeWidth={1.5} />
                    </div>
                    <span className="text-slate-600">{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Documents */}
            <div>
              <span className="text-xs tracking-widest uppercase text-slate-400 mb-6 block">Documente</span>
              <h3 className="text-2xl font-medium text-slate-900 mb-8">Documente necesare</h3>
              <ul className="space-y-4">
                {documents.map((doc, index) => (
                  <li key={index} className="flex items-start gap-4">
                    <div className="w-6 h-6 bg-slate-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <FileText className="w-3 h-3 text-slate-700" strokeWidth={1.5} />
                    </div>
                    <span className="text-slate-600">{doc}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">Proces</span>
            <h2 className="text-3xl font-medium text-slate-900">
              Cum te înscrii
            </h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step) => (
              <div key={step.number} className="relative">
                <span className="text-6xl font-medium text-slate-100 mb-4 block">{step.number}</span>
                <h3 className="font-medium text-slate-900 mb-2">{step.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-slate-900">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-xs tracking-widest uppercase text-white/40 mb-6 block">Contact</span>
              <h2 className="text-3xl font-medium text-white mb-4">
                Ai întrebări?
              </h2>
              <p className="text-white/50 leading-relaxed mb-8">
                Contactează-ne pentru orice informație suplimentară despre cursurile noastre 
                și procesul de înscriere.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-3 px-6 py-3.5 bg-white text-slate-900 text-sm tracking-wide hover:bg-white/90 transition-colors"
                >
                  <span>Contactează-ne</span>
                  <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
                </Link>
              </div>
            </div>
            <div className="space-y-6">
              <div className="flex items-center gap-4 text-white">
                <div className="w-12 h-12 bg-white/5 flex items-center justify-center">
                  <Phone className="w-5 h-5" strokeWidth={1.5} />
                </div>
                <div>
                  <div className="text-xs text-white/40 mb-1">Telefon</div>
                  <div className="text-white">0726 678 535</div>
                </div>
              </div>
              <div className="flex items-center gap-4 text-white">
                <div className="w-12 h-12 bg-white/5 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5" strokeWidth={1.5} />
                </div>
                <div>
                  <div className="text-xs text-white/40 mb-1">Email</div>
                  <div className="text-white">baiamare@aeroclubulromaniei.ro</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Notice */}
      <section className="py-12 bg-amber-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-amber-100 flex items-center justify-center flex-shrink-0">
              <AlertCircle className="w-5 h-5 text-amber-700" strokeWidth={1.5} />
            </div>
            <div>
              <h3 className="font-medium text-amber-900 mb-2">Notă importantă</h3>
              <p className="text-amber-800/80 text-sm leading-relaxed">
                Locurile pentru cursurile gratuite sunt limitate și se ocupă în ordinea înscrierii. 
                Pentru cursurile cu plată, vă rugăm să ne contactați pentru informații despre tarife 
                și disponibilitate.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
