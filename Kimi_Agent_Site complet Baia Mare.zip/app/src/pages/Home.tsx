import { useEffect, useRef } from 'react';
import { ArrowRight, ArrowDownRight, Plane, Wind, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const stats = [
  { value: '90+', label: 'Ani de tradiție', suffix: '' },
  { value: '25.000', label: 'Vizitatori anuali', suffix: '+' },
  { value: '40.000', label: 'Mișcări anuale', suffix: '+' },
];

export function Home() {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const scrollY = window.scrollY;
        const img = heroRef.current.querySelector('.hero-image') as HTMLElement;
        if (img) {
          img.style.transform = `translateY(${scrollY * 0.3}px) scale(${1 + scrollY * 0.0002})`;
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen bg-slate-950 overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <div className="hero-image absolute inset-0 will-change-transform">
            <img
              src="/hero-aerodrom.jpg"
              alt="Aerodromul Baia Mare"
              className="w-full h-full object-cover opacity-60"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/60 via-slate-950/40 to-slate-950" />
        </div>

        {/* Content */}
        <div className="relative z-10 min-h-screen flex flex-col">
          {/* Main Hero Content */}
          <div className="flex-1 flex items-center">
            <div className="max-w-7xl mx-auto px-6 lg:px-8 w-full py-32">
              <div className="grid lg:grid-cols-2 gap-16 items-end">
                {/* Left - Main Text */}
                <div className="space-y-8">
                  <div className="flex items-center gap-3 text-white/60">
                    <div className="w-12 h-px bg-white/30" />
                    <span className="text-xs tracking-widest uppercase">Aeroclubul Teritorial "Alexandru Papană"</span>
                  </div>
                  
                  <h1 className="text-5xl sm:text-6xl lg:text-7xl font-medium text-white leading-[0.95] tracking-tight">
                    Aerodromul
                    <span className="block text-white/40">Baia Mare</span>
                  </h1>
                  
                  <p className="text-lg text-white/60 max-w-md leading-relaxed">
                    Școală de zbor autorizată, aviație sportivă și zboruri de agrement 
                    în inima Maramureșului.
                  </p>

                  <div className="flex flex-wrap gap-4 pt-4">
                    <Link
                      to="/servicii"
                      className="group inline-flex items-center gap-3 px-6 py-3.5 bg-white text-slate-900 text-sm tracking-wide hover:bg-white/90 transition-colors"
                    >
                      <span>Descoperă serviciile</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" strokeWidth={1.5} />
                    </Link>
                    <Link
                      to="/aerodrom"
                      className="inline-flex items-center gap-3 px-6 py-3.5 border border-white/20 text-white text-sm tracking-wide hover:bg-white/5 transition-colors"
                    >
                      <span>Informații piloți</span>
                    </Link>
                  </div>
                </div>

                {/* Right - Stats */}
                <div className="hidden lg:block">
                  <div className="space-y-8">
                    {stats.map((stat) => (
                      <div key={stat.label} className="flex items-baseline gap-2">
                        <span className="text-5xl font-medium text-white">{stat.value}</span>
                        <span className="text-2xl text-white/40">{stat.suffix}</span>
                        <span className="text-sm text-white/50 ml-2">{stat.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-white/10">
            <div className="max-w-7xl mx-auto px-6 lg:px-8 py-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-6 text-sm text-white/50">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" strokeWidth={1.5} />
                    <span>Tăuții-Măgherăuș, 7.5 km de Baia Mare</span>
                  </div>
                </div>
                <div className="flex items-center gap-8 text-sm">
                  <div className="text-white/40">
                    <span className="text-white/60">Cod ICAO</span>
                    <span className="ml-2 text-white">LRMM</span>
                  </div>
                  <div className="text-white/40">
                    <span className="text-white/60">Elevație</span>
                    <span className="ml-2 text-white">184.8 m</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-16">
            {/* Left - Label */}
            <div className="lg:col-span-3">
              <div className="sticky top-32">
                <span className="text-xs tracking-widest uppercase text-slate-400">Despre noi</span>
              </div>
            </div>

            {/* Right - Content */}
            <div className="lg:col-span-9">
              <div className="max-w-3xl">
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-medium text-slate-900 leading-tight mb-8">
                  Un punct de referință pentru aviația sportivă din{' '}
                  <span className="text-slate-400">Maramureș</span>
                </h2>
                
                <div className="prose prose-lg prose-slate max-w-none">
                  <p className="text-slate-600 leading-relaxed">
                    Aeroclubul Teritorial "Alexandru Papană" Baia Mare este una dintre cele mai 
                    importante baze de aviație sportivă din România. Cu o tradiție de peste 90 de ani, 
                    am format generații de piloți și parașutiști, contribuind la dezvoltarea aviației 
                    civile și sportive din țară.
                  </p>
                  <p className="text-slate-600 leading-relaxed">
                    Situat în Tăuții-Măgherăuș, la doar 7.5 km de municipiul Baia Mare, aerodromul 
                    nostru oferă condiții excelente pentru zboruri de agrement, școală de zbor și 
                    activități parașutiste, cu o pistă de 500m și facilități moderne.
                  </p>
                </div>

                {/* Features Grid */}
                <div className="grid sm:grid-cols-2 gap-6 mt-12 pt-12 border-t border-slate-100">
                  {[
                    { icon: Plane, title: 'Școală de zbor', desc: 'Cursuri pentru licențe LAPL, SPL și PPL' },
                    { icon: Wind, title: 'Planorism', desc: 'Zbor fără motor cu planoare moderne' },
                  ].map((feature) => (
                    <div key={feature.title} className="group">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-slate-100 flex items-center justify-center group-hover:bg-slate-900 group-hover:text-white transition-colors">
                          <feature.icon className="w-5 h-5" strokeWidth={1.5} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-900 mb-1">{feature.title}</h3>
                          <p className="text-sm text-slate-500">{feature.desc}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Image Section */}
      <section className="relative h-[70vh] overflow-hidden">
        <img
          src="/hangar.jpg"
          alt="Hangar"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-slate-950/30" />
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-7xl mx-auto px-6 lg:px-8 w-full pb-16">
            <div className="bg-white/95 backdrop-blur-sm p-8 max-w-md">
              <span className="text-xs tracking-widest uppercase text-slate-400 mb-3 block">Facilități</span>
              <h3 className="text-2xl font-medium text-slate-900 mb-3">Hangar și service autorizat</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Dispunem de hangar modern pentru aeronave și service tehnic autorizat 
                pentru întreținerea flotei noastre.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-16">
            <div>
              <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">Servicii</span>
              <h2 className="text-3xl sm:text-4xl font-medium text-slate-900">
                Experiențe de zbor
              </h2>
            </div>
            <Link 
              to="/servicii" 
              className="group inline-flex items-center gap-2 text-sm text-slate-600 hover:text-slate-900 transition-colors"
            >
              <span>Vezi toate serviciile</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" strokeWidth={1.5} />
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                image: '/avion-zbor.jpg',
                title: 'Zbor de inițiere',
                price: 'de la 350 lei',
                desc: '20-30 minute la manșa unui avion ușor',
              },
              {
                image: '/planor.jpg',
                title: 'Zbor cu planorul',
                price: 'de la 250 lei',
                desc: 'Zbor panoramic fără motor',
              },
              {
                image: '/parasutism.jpg',
                title: 'Salt tandem',
                price: 'de la 1.200 lei',
                desc: 'Salt cu parașuta însoțit de instructor',
              },
            ].map((service) => (
              <Link 
                key={service.title} 
                to="/servicii"
                className="group block bg-white"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium text-slate-900">{service.title}</h3>
                    <ArrowDownRight className="w-4 h-4 text-slate-400 group-hover:text-slate-900 group-hover:translate-x-0.5 group-hover:translate-y-0.5 transition-all" strokeWidth={1.5} />
                  </div>
                  <p className="text-sm text-slate-500 mb-3">{service.desc}</p>
                  <span className="text-sm font-medium text-slate-900">{service.price}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-slate-900">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-xs tracking-widest uppercase text-white/40 mb-6 block">Contact</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-medium text-white leading-tight mb-6">
                Hai să zburăm împreună
              </h2>
              <p className="text-white/60 leading-relaxed mb-8 max-w-md">
                Contactează-ne pentru a programa un zbor sau pentru mai multe informații 
                despre cursurile noastre.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-3 px-6 py-3.5 bg-white text-slate-900 text-sm tracking-wide hover:bg-white/90 transition-colors"
                >
                  <span>Contactează-ne</span>
                  <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
                </Link>
                <a
                  href="tel:0726678535"
                  className="inline-flex items-center gap-3 px-6 py-3.5 border border-white/20 text-white text-sm tracking-wide hover:bg-white/5 transition-colors"
                >
                  <span>0726 678 535</span>
                </a>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="relative">
                <div className="absolute -inset-4 bg-white/5" />
                <img
                  src="/pilot.jpg"
                  alt="Pilot"
                  className="relative w-full aspect-[3/4] object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
