import { 
  Plane, 
  Wind, 
  ArrowRight,
  ArrowUpRight,
  Clock,
  Gift,
  CheckCircle2
} from 'lucide-react';
import { Link } from 'react-router-dom';

const mainServices = [
  {
    icon: Plane,
    title: 'Zbor de inițiere',
    subtitle: 'Avion',
    description: 'Experimentează senzația zborului la manșa unui avion ușor, însoțit de un instructor experimentat.',
    duration: '20-30 minute',
    price: '350 lei',
    image: '/avion-zbor.jpg',
    features: ['Briefing pre-zbor', 'Zbor cu instructor', 'Certificat de participare'],
    popular: true,
  },
  {
    icon: Wind,
    title: 'Zbor cu planorul',
    subtitle: 'Planor',
    description: 'Zbor liniștit și panoramic cu planorul, ideal pentru cei care vor să experimenteze zborul fără motor.',
    duration: '15-20 minute',
    price: '250 lei',
    image: '/planor.jpg',
    features: ['Tracțiune cu avion', 'Zbor panoramic', 'Fotografii din aer'],
    popular: false,
  },
];

const giftVouchers = [
  {
    title: 'Voucher Zbor Avion',
    description: 'Un cadou perfect pentru pasionații de aviație',
    price: '350 lei',
    includes: ['Zbor de 20-30 minute', 'Briefing pre-zbor', 'Certificat de participare'],
  },
  {
    title: 'Voucher Zbor Planor',
    description: 'Experiență unică de zbor fără motor',
    price: '250 lei',
    includes: ['Zbor de 15-20 minute', 'Tracțiune cu avion', 'Fotografii din aer'],
  },
  {
    title: 'Voucher Salt Parașuta',
    description: 'O experiență de neuitat pentru iubitorii de adrenalină',
    price: '1.200 lei',
    includes: ['Salt tandem de la 3000m', 'Echipament complet', 'Instructor profesionist'],
  },
];

export function Servicii() {
  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center gap-3 text-white/40 mb-6">
            <div className="w-12 h-px bg-white/20" />
            <span className="text-xs tracking-widest uppercase">Servicii</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-medium text-white leading-tight max-w-3xl mb-6">
            Experiențe de zbor
          </h1>
          <p className="text-lg text-white/50 max-w-xl">
            Oferim o gamă completă de servicii de aviație sportivă, de la zboruri de inițiere 
            până la salturi cu parașuta.
          </p>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="mb-16">
            <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">Zboruri</span>
            <h2 className="text-3xl font-medium text-slate-900">
              Alege experiența potrivită
            </h2>
          </div>

          <div className="space-y-12">
            {mainServices.map((service, index) => (
              <div 
                key={service.title} 
                className={`grid lg:grid-cols-2 gap-0 ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}
              >
                {/* Image */}
                <div className={`relative aspect-[4/3] lg:aspect-auto overflow-hidden ${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                  {service.popular && (
                    <div className="absolute top-6 left-6 px-3 py-1.5 bg-white text-slate-900 text-xs tracking-wide">
                      Popular
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className={`bg-slate-50 p-8 lg:p-12 flex flex-col justify-center ${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 bg-white flex items-center justify-center">
                      <service.icon className="w-5 h-5 text-slate-700" strokeWidth={1.5} />
                    </div>
                    <span className="text-xs tracking-widest uppercase text-slate-400">{service.subtitle}</span>
                  </div>
                  
                  <h3 className="text-2xl font-medium text-slate-900 mb-4">{service.title}</h3>
                  <p className="text-slate-600 leading-relaxed mb-6">{service.description}</p>
                  
                  <div className="flex items-center gap-2 text-sm text-slate-500 mb-8">
                    <Clock className="w-4 h-4" strokeWidth={1.5} />
                    <span>{service.duration}</span>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-3 text-sm text-slate-600">
                        <CheckCircle2 className="w-4 h-4 text-green-600" strokeWidth={1.5} />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="flex items-center justify-between pt-6 border-t border-slate-200">
                    <div>
                      <span className="text-xs text-slate-400 block mb-1">Preț</span>
                      <span className="text-2xl font-medium text-slate-900">{service.price}</span>
                    </div>
                    <a
                      href="https://magazin.aeroclubulromaniei.ro/vouchere-zbor"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-6 py-3 bg-slate-900 text-white text-sm tracking-wide hover:bg-slate-800 transition-colors"
                    >
                      <span>Rezervă</span>
                      <ArrowUpRight className="w-4 h-4" strokeWidth={1.5} />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gift Vouchers */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-16">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Gift className="w-5 h-5 text-slate-400" strokeWidth={1.5} />
                <span className="text-xs tracking-widest uppercase text-slate-400">Vouchere cadou</span>
              </div>
              <h2 className="text-3xl font-medium text-slate-900">
                Oferă un cadou de neuitat
              </h2>
            </div>
            <a 
              href="https://magazin.aeroclubulromaniei.ro/vouchere-zbor"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm text-slate-600 hover:text-slate-900 transition-colors"
            >
              <span>Vezi toate voucherele</span>
              <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
            </a>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {giftVouchers.map((voucher) => (
              <div key={voucher.title} className="bg-white p-8 border border-slate-200 hover:border-slate-300 transition-colors">
                <div className="w-12 h-12 bg-slate-100 flex items-center justify-center mb-6">
                  <Gift className="w-5 h-5 text-slate-700" strokeWidth={1.5} />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-2">{voucher.title}</h3>
                <p className="text-sm text-slate-500 mb-6">{voucher.description}</p>
                <div className="text-2xl font-medium text-slate-900 mb-6">{voucher.price}</div>
                <ul className="space-y-2 mb-8">
                  {voucher.includes.map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-slate-600">
                      <CheckCircle2 className="w-4 h-4 text-green-600" strokeWidth={1.5} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href="https://magazin.aeroclubulromaniei.ro/vouchere-zbor"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full py-3 border border-slate-200 text-center text-sm text-slate-700 hover:border-slate-900 hover:text-slate-900 transition-colors"
                >
                  Cumpără voucher
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-slate-900">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-3xl font-medium text-white mb-4">
              Rezervă-ți zborul acum
            </h2>
            <p className="text-white/50 mb-8">
              Contactează-ne pentru a programa zborul tău sau pentru a cumpăra un voucher cadou.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link
                to="/contact"
                className="inline-flex items-center gap-3 px-6 py-3.5 bg-white text-slate-900 text-sm tracking-wide hover:bg-white/90 transition-colors"
              >
                <span>Contactează-ne</span>
                <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
              </Link>
              <a
                href="https://magazin.aeroclubulromaniei.ro/vouchere-zbor"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 px-6 py-3.5 border border-white/20 text-white text-sm tracking-wide hover:bg-white/5 transition-colors"
              >
                <span>Magazin online</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
