import { 
  ArrowRight,
  CheckCircle2,
  Info
} from 'lucide-react';
import { Link } from 'react-router-dom';

const aircraft = [
  {
    name: 'PZL-104 Wilga 35A',
    type: 'Avion utilitar',
    image: '/avion-zbor.jpg',
    description: 'Avion utilitar polonez, robust și versatil, ideal pentru zboruri de agrement, școală de zbor și remorcarea planoarelor.',
    specs: {
      echipaj: '1 pilot',
      capacitate: '3 pasageri',
      anvergura: '11.12 m',
      greutate: '1,100 kg',
      motor: 'AI-14R 260 CP',
      vmax: '200 km/h',
    },
    tags: ['Zbor școală', 'Remorcare', 'Agrement'],
  },
  {
    name: 'SZD-50 Puchacz',
    type: 'Planor',
    image: '/planor.jpg',
    description: 'Planor polonez cu două locuri, excelent pentru școală de planorism și zboruri de agrement.',
    specs: {
      echipaj: '1 pilot',
      capacitate: '1 pasager',
      anvergura: '16.0 m',
      greutate: '420 kg',
      motor: 'Fără motor',
      vmax: '250 km/h',
    },
    tags: ['Planorism', 'Școală', 'Acrobație'],
  },
  {
    name: 'SZD-30 Pirat',
    type: 'Planor',
    image: '/planor.jpg',
    description: 'Planor monoloc clasic, foarte popular pentru zborul solo și acrobație cu planorul.',
    specs: {
      echipaj: '1 pilot',
      capacitate: '-',
      anvergura: '15.0 m',
      greutate: '330 kg',
      motor: 'Fără motor',
      vmax: '220 km/h',
    },
    tags: ['Planorism', 'Solo', 'Acrobație'],
  },
];

const stats = [
  { value: '12+', label: 'Aeronave' },
  { value: '8', label: 'Tipuri' },
  { value: '90+', label: 'Ani experiență' },
  { value: '1000+', label: 'Piloți formați' },
];

export function Flota() {
  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center gap-3 text-white/40 mb-6">
            <div className="w-12 h-px bg-white/20" />
            <span className="text-xs tracking-widest uppercase">Flotă</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-medium text-white leading-tight max-w-3xl mb-6">
            Aeronavele noastre
          </h1>
          <p className="text-lg text-white/50 max-w-xl">
            O flotă diversificată de aeronave moderne și bine întreținute, pregătite 
            să îți ofere cea mai bună experiență de zbor.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-slate-900 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label}>
                <div className="text-4xl font-medium text-white mb-1">{stat.value}</div>
                <div className="text-sm text-white/40">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Aircraft List */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="mb-16">
            <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">Aeronave</span>
            <h2 className="text-3xl font-medium text-slate-900">
              Descoperă flota
            </h2>
          </div>

          <div className="space-y-24">
            {aircraft.map((plane, index) => (
              <div key={plane.name} className="grid lg:grid-cols-2 gap-12 items-center">
                {/* Image */}
                <div className={`relative ${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                  <div className="aspect-[4/3] overflow-hidden bg-slate-100">
                    <img
                      src={plane.image}
                      alt={plane.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <span className="px-3 py-1.5 bg-white text-slate-900 text-xs tracking-wide">
                      {plane.type}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                  <h3 className="text-2xl font-medium text-slate-900 mb-4">{plane.name}</h3>
                  <p className="text-slate-600 leading-relaxed mb-6">{plane.description}</p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-8">
                    {plane.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 bg-slate-100 text-slate-600 text-xs"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Specs */}
                  <div className="grid grid-cols-2 gap-4 mb-8">
                    {Object.entries(plane.specs).map(([key, value]) => (
                      <div key={key} className="py-3 border-b border-slate-100">
                        <span className="text-xs text-slate-400 uppercase tracking-wide block mb-1">
                          {key === 'vmax' ? 'Viteză max' : key}
                        </span>
                        <span className="text-slate-900">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Maintenance */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-white flex items-center justify-center">
                  <Info className="w-5 h-5 text-slate-700" strokeWidth={1.5} />
                </div>
                <span className="text-xs tracking-widest uppercase text-slate-400">Întreținere</span>
              </div>
              <h2 className="text-3xl font-medium text-slate-900 mb-6">
                Siguranță și calitate
              </h2>
              <p className="text-slate-600 leading-relaxed mb-8">
                Toate aeronavele noastre sunt supuse unor controale tehnice riguroase și 
                întrețineri periodice conform standardelor AACR. Siguranța pasagerilor și 
                a piloților este prioritatea noastră numărul unu.
              </p>
              <ul className="space-y-4">
                {[
                  'Verificări tehnice zilnice',
                  'Inspecții periodice autorizate',
                  'Personal tehnic calificat',
                  'Piese de schimb originale',
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-600">
                    <CheckCircle2 className="w-4 h-4 text-green-600" strokeWidth={1.5} />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white p-8">
              <h3 className="text-lg font-medium text-slate-900 mb-6">Certificări</h3>
              <div className="space-y-4">
                {[
                  { label: 'Certificare AACR', status: 'Valabilă' },
                  { label: 'Autorizație funcționare', status: 'Valabilă' },
                  { label: 'Asigurare RCA/Aviație', status: 'Valabilă' },
                ].map((cert) => (
                  <div key={cert.label} className="flex items-center justify-between py-3 border-b border-slate-100 last:border-0">
                    <span className="text-slate-600">{cert.label}</span>
                    <span className="px-3 py-1 bg-green-100 text-green-700 text-xs">{cert.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-slate-900">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-3xl font-medium text-white mb-4">
              Vrei să zbori cu noi?
            </h2>
            <p className="text-white/50 mb-8">
              Rezervă-ți acum un zbor cu una dintre aeronavele noastre și trăiește 
              experiența unică a zborului.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link
                to="/servicii"
                className="inline-flex items-center gap-3 px-6 py-3.5 bg-white text-slate-900 text-sm tracking-wide hover:bg-white/90 transition-colors"
              >
                <span>Vezi serviciile</span>
                <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-3 px-6 py-3.5 border border-white/20 text-white text-sm tracking-wide hover:bg-white/5 transition-colors"
              >
                <span>Contactează-ne</span>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
