import { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send,
  ArrowRight,
  CheckCircle2,
  Facebook,
  ExternalLink
} from 'lucide-react';

const contactInfo = [
  {
    icon: Phone,
    title: 'Telefon',
    value: '0726 678 535',
    href: 'tel:0726678535',
  },
  {
    icon: Mail,
    title: 'Email',
    value: 'baiamare@aeroclubulromaniei.ro',
    href: 'mailto:baiamare@aeroclubulromaniei.ro',
  },
  {
    icon: MapPin,
    title: 'Adresă',
    value: 'Str. 66, Nr. 5, Tăuții-Măgherăuș',
  },
  {
    icon: Clock,
    title: 'Program',
    value: 'Regim HX (Răsărit - Apus)',
  },
];

const faqs = [
  {
    q: 'Ce vârstă trebuie să am pentru a zbura?',
    a: 'Pentru zboruri de agrement nu există limită de vârstă. Pentru cursurile de pilot, vârsta minimă este 16 ani pentru planor și 17 ani pentru avion.',
  },
  {
    q: 'Am nevoie de programare pentru un zbor?',
    a: 'Da, recomandăm să ne contactați cu cel puțin 3-5 zile în avans pentru a programa zborul.',
  },
  {
    q: 'Ce se întâmplă dacă vremea nu este bună?',
    a: 'Siguranța este prioritatea noastră. Dacă condițiile meteorologice nu permit zborul, vom reprograma.',
  },
  {
    q: 'Pot oferi un voucher cadou?',
    a: 'Da, oferim vouchere cadou pentru toate serviciile noastre, valabile 12 luni.',
  },
];

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setFormData({ name: '', email: '', phone: '', message: '' });
    }, 100);
  };

  return (
    <div className="pt-20">
      {/* Header */}
      <section className="py-24 bg-slate-950">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center gap-3 text-white/40 mb-6">
            <div className="w-12 h-px bg-white/20" />
            <span className="text-xs tracking-widest uppercase">Contact</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-medium text-white leading-tight max-w-3xl mb-6">
            Hai să vorbim
          </h1>
          <p className="text-lg text-white/50 max-w-xl">
            Contactează-ne pentru orice informație legată de serviciile și facilitățile noastre.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Left - Contact Info */}
            <div>
              <span className="text-xs tracking-widest uppercase text-slate-400 mb-6 block">Informații</span>
              <h2 className="text-2xl font-medium text-slate-900 mb-8">
                Date de contact
              </h2>

              <div className="space-y-6 mb-12">
                {contactInfo.map((item) => (
                  <div key={item.title} className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-slate-100 flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-5 h-5 text-slate-600" strokeWidth={1.5} />
                    </div>
                    <div>
                      <span className="text-xs text-slate-400 uppercase tracking-wide block mb-1">
                        {item.title}
                      </span>
                      {item.href ? (
                        <a 
                          href={item.href}
                          className="text-slate-900 hover:text-slate-600 transition-colors"
                        >
                          {item.value}
                        </a>
                      ) : (
                        <span className="text-slate-900">{item.value}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Social */}
              <div>
                <span className="text-xs text-slate-400 uppercase tracking-wide block mb-4">
                  Social
                </span>
                <div className="flex gap-3">
                  <a
                    href="https://www.facebook.com/AeroclubulRomaniei"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-slate-900 flex items-center justify-center text-white hover:bg-slate-700 transition-colors"
                  >
                    <Facebook className="w-5 h-5" strokeWidth={1.5} />
                  </a>
                  <a
                    href="https://aeroclubulromaniei.ro"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200 transition-colors"
                  >
                    <ExternalLink className="w-5 h-5" strokeWidth={1.5} />
                  </a>
                </div>
              </div>
            </div>

            {/* Right - Form */}
            <div className="bg-slate-50 p-8 lg:p-12">
              {submitted ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-green-100 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-8 h-8 text-green-600" strokeWidth={1.5} />
                  </div>
                  <h3 className="text-xl font-medium text-slate-900 mb-2">Mesaj trimis</h3>
                  <p className="text-slate-500 mb-6">Îți mulțumim. Te vom contacta în curând.</p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="text-sm text-slate-600 hover:text-slate-900 transition-colors"
                  >
                    Trimite alt mesaj
                  </button>
                </div>
              ) : (
                <>
                  <span className="text-xs tracking-widest uppercase text-slate-400 mb-6 block">Formular</span>
                  <h3 className="text-xl font-medium text-slate-900 mb-8">
                    Trimite-ne un mesaj
                  </h3>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label className="text-xs text-slate-400 uppercase tracking-wide block mb-2">
                        Nume complet *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:border-slate-400 transition-colors"
                        placeholder="Ion Popescu"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-400 uppercase tracking-wide block mb-2">
                        Email *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:border-slate-400 transition-colors"
                        placeholder="ion@example.com"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-400 uppercase tracking-wide block mb-2">
                        Telefon
                      </label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:border-slate-400 transition-colors"
                        placeholder="07xx xxx xxx"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-slate-400 uppercase tracking-wide block mb-2">
                        Mesaj *
                      </label>
                      <textarea
                        required
                        rows={4}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="w-full px-4 py-3 bg-white border border-slate-200 text-slate-900 text-sm focus:outline-none focus:border-slate-400 transition-colors resize-none"
                        placeholder="Cum te putem ajuta?"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-slate-900 text-white text-sm tracking-wide hover:bg-slate-800 transition-colors"
                    >
                      <span>Trimite mesajul</span>
                      <Send className="w-4 h-4" strokeWidth={1.5} />
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Map */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="mb-8">
            <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">Locație</span>
            <h2 className="text-2xl font-medium text-slate-900">
              Unde ne găsești
            </h2>
          </div>
          <div className="aspect-video bg-slate-200">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2689.1234567890123!2d23.45!3d47.65!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDfCsDM5JzAwLjAiTiAyM8KwMjcnMDAuMCJF!5e0!3m2!1sro!2sro!4v1234567890"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Aerodromul Baia Mare"
              className="grayscale"
            />
          </div>
          <div className="mt-6 flex flex-wrap gap-6 text-sm text-slate-500">
            <div>Coordonate: 47°40'N, 23°28'E</div>
            <div>Cod ICAO: LRMM</div>
            <div>Elevație: 184.8 m</div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-white">
        <div className="max-w-3xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-xs tracking-widest uppercase text-slate-400 mb-4 block">FAQ</span>
            <h2 className="text-3xl font-medium text-slate-900">
              Întrebări frecvente
            </h2>
          </div>

          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="pb-6 border-b border-slate-100 last:border-0">
                <h3 className="font-medium text-slate-900 mb-2">{faq.q}</h3>
                <p className="text-slate-600 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-slate-900">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <h2 className="text-3xl font-medium text-white mb-4">
              Ești g să zbori?
            </h2>
            <p className="text-white/50 mb-8">
              Rezervă-ți acum un zbor și trăiește experiența unică a aviației sportive.
            </p>
            <a
              href="/servicii"
              className="inline-flex items-center gap-3 px-6 py-3.5 bg-white text-slate-900 text-sm tracking-wide hover:bg-white/90 transition-colors"
            >
              <span>Vezi serviciile</span>
              <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
