import { useState, useEffect } from 'react';
import { Menu, X, Plane } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const navLinks = [
  { href: '/', label: 'Acasă' },
  { href: '/aerodrom', label: 'Date Aerodrom' },
  { href: '/inscrieri', label: 'Înscrieri' },
  { href: '/servicii', label: 'Servicii' },
  { href: '/flota', label: 'Flotă' },
  { href: '/contact', label: 'Contact' },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname === path) return true;
    return false;
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md border-b border-slate-200/50'
            : 'bg-transparent'
        }`}
      >
        <nav className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className={`relative transition-all duration-300 ${
                isScrolled ? 'text-slate-900' : 'text-white'
              }`}>
                <Plane className="w-7 h-7 transform -rotate-45 group-hover:-rotate-35 transition-transform duration-300" strokeWidth={1.5} />
              </div>
              <div className="flex flex-col">
                <span className={`font-medium text-sm tracking-wide uppercase transition-colors ${
                  isScrolled ? 'text-slate-900' : 'text-white'
                }`}>
                  Aerodromul
                </span>
                <span className={`text-xs tracking-widest uppercase transition-colors ${
                  isScrolled ? 'text-slate-500' : 'text-white/70'
                }`}>
                  Baia Mare
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  className={`relative px-4 py-2 text-sm tracking-wide transition-all duration-300 ${
                    isActive(link.href)
                      ? isScrolled
                        ? 'text-slate-900'
                        : 'text-white'
                      : isScrolled
                        ? 'text-slate-500 hover:text-slate-900'
                        : 'text-white/70 hover:text-white'
                  }`}
                >
                  {link.label}
                  {isActive(link.href) && (
                    <span className="absolute bottom-0 left-4 right-4 h-px bg-current" />
                  )}
                </Link>
              ))}
            </div>

            {/* CTA */}
            <div className="hidden lg:flex items-center gap-6">
              <a 
                href="tel:0726678535" 
                className={`text-sm tracking-wide transition-colors ${
                  isScrolled ? 'text-slate-600 hover:text-slate-900' : 'text-white/80 hover:text-white'
                }`}
              >
                0726 678 535
              </a>
              <Link
                to="/servicii"
                className={`px-5 py-2.5 text-sm tracking-wide transition-all duration-300 ${
                  isScrolled
                    ? 'bg-slate-900 text-white hover:bg-slate-800'
                    : 'bg-white/10 backdrop-blur-sm text-white border border-white/20 hover:bg-white/20'
                }`}
              >
                Rezervă zbor
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`lg:hidden p-2 transition-colors ${
                isScrolled ? 'text-slate-900' : 'text-white'
              }`}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" strokeWidth={1.5} /> : <Menu className="w-6 h-6" strokeWidth={1.5} />}
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div 
            className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm"
            onClick={() => setIsMobileMenuOpen(false)}
          />
          <div className="absolute right-0 top-0 bottom-0 w-80 bg-white shadow-2xl">
            <div className="p-8 pt-24">
              <nav className="space-y-1">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    to={link.href}
                    className={`block py-3 text-lg border-b border-slate-100 transition-colors ${
                      isActive(link.href)
                        ? 'text-slate-900 font-medium'
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
              </nav>
              <div className="mt-8 pt-8 border-t border-slate-100">
                <a 
                  href="tel:0726678535" 
                  className="block text-slate-600 hover:text-slate-900 mb-4"
                >
                  0726 678 535
                </a>
                <Link
                  to="/servicii"
                  className="block w-full py-3 bg-slate-900 text-white text-center text-sm tracking-wide hover:bg-slate-800 transition-colors"
                >
                  Rezervă zbor
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
