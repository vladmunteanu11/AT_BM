import { Plane, MapPin, Phone, Mail, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const footerLinks = {
  navigare: [
    { label: 'Acasă', href: '/' },
    { label: 'Date Aerodrom', href: '/aerodrom' },
    { label: 'Înscrieri', href: '/inscrieri' },
    { label: 'Servicii', href: '/servicii' },
    { label: 'Flotă', href: '/flota' },
    { label: 'Contact', href: '/contact' },
  ],
  servicii: [
    { label: 'Zbor de inițiere', href: '/servicii' },
    { label: 'Planorism', href: '/servicii' },
    { label: 'Parașutism tandem', href: '/servicii' },
    { label: 'Zbor panoramic', href: '/servicii' },
    { label: 'Vouchere cadou', href: '/servicii' },
  ],
  legal: [
    { label: 'Termeni și condiții', href: '#' },
    { label: 'Politica de confidențialitate', href: '#' },
    { label: 'Cookies', href: '#' },
  ],
};

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-5">
            <Link to="/" className="inline-flex items-center gap-3 mb-8">
              <Plane className="w-8 h-8 text-white/80" strokeWidth={1.5} />
              <div>
                <div className="text-lg font-medium tracking-tight">Aerodromul Baia Mare</div>
                <div className="text-xs text-white/40 tracking-widest uppercase">Aeroclubul "Alexandru Papană"</div>
              </div>
            </Link>
            <p className="text-white/50 text-sm leading-relaxed max-w-sm mb-8">
              Școală de zbor autorizată, aviație sportivă și zboruri de agrement 
              în inima Maramureșului. Tradiție și pasiune pentru zbor din 1930.
            </p>
            <div className="space-y-3">
              <a href="tel:0726678535" className="flex items-center gap-3 text-white/60 hover:text-white transition-colors text-sm">
                <Phone className="w-4 h-4" strokeWidth={1.5} />
                <span>0726 678 535</span>
              </a>
              <a href="mailto:baiamare@aeroclubulromaniei.ro" className="flex items-center gap-3 text-white/60 hover:text-white transition-colors text-sm">
                <Mail className="w-4 h-4" strokeWidth={1.5} />
                <span>baiamare@aeroclubulromaniei.ro</span>
              </a>
              <div className="flex items-start gap-3 text-white/60 text-sm">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" strokeWidth={1.5} />
                <span>Str. 66, Nr. 5<br />Tăuții-Măgherăuș, MM</span>
              </div>
            </div>
          </div>

          {/* Links Columns */}
          <div className="lg:col-span-7">
            <div className="grid sm:grid-cols-3 gap-8">
              {/* Navigation */}
              <div>
                <h4 className="text-xs font-medium tracking-widest uppercase text-white/40 mb-6">
                  Navigare
                </h4>
                <ul className="space-y-3">
                  {footerLinks.navigare.map((link) => (
                    <li key={link.label}>
                      <Link
                        to={link.href}
                        className="text-white/60 hover:text-white transition-colors text-sm inline-flex items-center gap-1 group"
                      >
                        {link.label}
                        <ArrowUpRight className="w-3 h-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Services */}
              <div>
                <h4 className="text-xs font-medium tracking-widest uppercase text-white/40 mb-6">
                  Servicii
                </h4>
                <ul className="space-y-3">
                  {footerLinks.servicii.map((link) => (
                    <li key={link.label}>
                      <Link
                        to={link.href}
                        className="text-white/60 hover:text-white transition-colors text-sm inline-flex items-center gap-1 group"
                      >
                        {link.label}
                        <ArrowUpRight className="w-3 h-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Legal */}
              <div>
                <h4 className="text-xs font-medium tracking-widest uppercase text-white/40 mb-6">
                  Legal
                </h4>
                <ul className="space-y-3">
                  {footerLinks.legal.map((link) => (
                    <li key={link.label}>
                      <Link
                        to={link.href}
                        className="text-white/60 hover:text-white transition-colors text-sm inline-flex items-center gap-1 group"
                      >
                        {link.label}
                        <ArrowUpRight className="w-3 h-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-white/40 text-xs">
              © {currentYear} Aerodromul Baia Mare. Toate drepturile rezervate.
            </div>
            <div className="flex items-center gap-6">
              <a 
                href="https://aeroclubulromaniei.ro" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white/40 hover:text-white text-xs transition-colors"
              >
                Aeroclubul României
              </a>
              <a 
                href="https://legitimare.ar.ro" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white/40 hover:text-white text-xs transition-colors"
              >
                Legitimare AR
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
